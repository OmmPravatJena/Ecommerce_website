<?php
$URL = "http://localhost/Flipkart-Clone-PHP";
?>